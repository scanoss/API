import argparse
import copy
import yaml
import sys
from openapi_spec_gen.parser import parse
from openapi_spec_validator import validate_spec, exceptions


def main():
  parser = argparse.ArgumentParser(
      description='OpenAPI 3.0 Document Generator')
  parser.add_argument('folder', metavar='DIR', type=str,
                      help='Directory of the project with annotated comments')
  args = parser.parse_args()
  oo_dict = parse(args.folder)
  if oo_dict:
    # Validate might modify array.
    copy_oodict = copy.deepcopy(oo_dict)
    validate_spec(copy_oodict)
    print(yaml.dump(oo_dict,sort_keys=False))
