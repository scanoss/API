import yaml
# /**
#  * @openapi-method
#  * name: listCodes
#  * request: GET /codes
#  * summary: List all codes
#  * tags: codes
#  * params:
#  * - name:limit
#  *   place: query
#  *   type: int32
#  *   required: false
#  *   description: "How many items to return at one time (max 100)"
#  * responses:
#  * - status: 200
#  *   description:"An paged array of pets"
#  *   schema:Code
#  * - status:500
#  *   description: "unexpected error"
#  *   schema: Error
#  *
#  */

SCHEMA_TMPL = '#/components/schemas/{}'
PRIMITIVE_TYPES = ['boolean', 'integer', 'number', 'string']
PARAM_TYPES = ['query', 'path', 'cookie', 'header']


class UnsupportedOpenAPIType(Exception):
  pass


class OpenAPISchema(yaml.YAMLObject):

  def __init__(self, schema, format=''):
    self.schema = schema
    self.format = format

  def to_openapi(self):
    result = {}
    types = self.schema.split()
    if self.schema in PRIMITIVE_TYPES:
      result['type'] = self.schema
    elif types[0] == 'enum':
      result = {'type': 'string',
                'enum': types[1][1:-1].split(',')}
    else:
      result['$ref'] = SCHEMA_TMPL.format(self.schema)
    if self.format:
      result['format'] = self.format
    return result


class OpenAPIResponse(yaml.YAMLObject):
  yaml_tag = u'!OpenAPIResponse'

  def __init__(self, obj):
    self.status = str(obj['status'])
    self.description = obj['description']
    self.schema = obj.get('schema')
    self.content = obj.get('content') if obj.get(
        'content') else 'application/json'

  def to_openapi(self):
    result = {
        self.status: {
            'description': self.description,
        }
    }
    if self.schema:
      result[self.status]['content'] = {
          self.content: {
              'schema': OpenAPISchema(self.schema).to_openapi()
          }
      }

    return result

# Represents and OpenAPI parameter, translates between annotated and open api format.


class OpenAPIParam(yaml.YAMLObject):
  yaml_tag = u'!OpenAPIParam'

  def __init__(self, obj):
    self.name = obj['name']
    self.place = obj.get('place')
    self.type = obj['type']
    self.required = obj.get('required') if obj.get(
        'required') != None else True
    self.description = obj.get('description')

  def to_openapi(self):
    schema = OpenAPISchema(self.type)
    return {
        'name': self.name,
        'in': self.place,
        'description': self.description,
        'required': self.required,
        'schema': schema.to_openapi()
    }

  def to_openapi_prop(self):
    prop_obj = {}
    types = self.type.split()
    if self.type in PRIMITIVE_TYPES:
      prop_obj['type'] = self.type
    elif self.type == 'file':
      prop_obj['type'] = 'string'
      prop_obj['format'] = 'binary'
    elif types[0] == 'enum':
      prop_obj = {'type': 'string',
                  'enum': types[1][1:-1].split(',')}
    if self.description:
      prop_obj['description'] = self.description

    return prop_obj


# Multipart Request Body, used for all POST requests in ScanOSS.
class OpenAPIMultiPartRequestBody(yaml.YAMLObject):
  yaml_tag = u'!OpenAPIMultiPartRequestBody'

  def __init__(self, params):
    self.params = params

  def to_openapi(self):
    content_obj = {
        'content': {
            'multipart/form-data': {
                'schema': {
                    'type': 'object',
                    'properties': {param.name: param.to_openapi_prop() for param in self.params}
                }
            }
        }
    }
    return content_obj


class OpenAPIMethod(yaml.YAMLObject):
  yaml_tag = u'!OpenAPIMethod'

  def __init__(self, obj):
    self.operationId = obj['operationId']
    self.request = obj['request']
    methodpath = obj['request'].split()
    self.method = methodpath[0].lower()
    self.path = methodpath[1]
    self.description = obj['description']
    self.tags = obj['tags']
    self.multipart = None
    self.params = None
    if obj.get('params'):
      if self.method == 'post':
        self.multipart = OpenAPIMultiPartRequestBody(
            [OpenAPIParam(param) for param in obj['params']])
      else:
        self.params = [OpenAPIParam(param) for param in obj['params']]
    else:
      self.params = None
    self.responses = [OpenAPIResponse(response)
                      for response in obj['responses']]

  def to_openapi(self):
    method_obj = {
        'summary': self.description,
        'operationId': self.operationId,
        'tags': [self.tags],
        'responses': {response.status: response.to_openapi()[response.status] for response in self.responses}
    }
    if self.params:
      method_obj.update({'parameters': [param.to_openapi()
                                        for param in self.params]})
    elif self.multipart:
      method_obj.update({'requestBody': self.multipart.to_openapi()})
    oom = {
        self.path: {
            self.method: method_obj
        }
    }

    return oom

# TODO Validate property types and log to user.


class OpenAPIComponentSchema(yaml.YAMLObject):

  def __init__(self, obj):
    self.name = obj['name']
    self.description = obj.get('description')
    self.properties = None
    self.type = None
    if obj.get('properties'):
      self.properties = obj['properties']
    else:
      self.type = obj['type']

  def to_openapi(self):
    ooprops = None
    # There are two types of objects, normal objects and array objects.
    ootype = None
    # I. Normal objects
    if self.properties:
      ooprops = dict()
      for name, t in self.properties.items():
        if type(t) is str:
          self.handle_type(name, t, ooprops)
        else:
          self.handle_type(name, t['type'], ooprops)
          ooprops[name]['description'] = t['description']
    # II. Array objects
    elif self.type:
      types = self.type.split()
      if types[0] == 'array':
        ootype = {
            'type': 'array',
            'items': {
                '$ref': SCHEMA_TMPL.format(types[1])
            }
        }

    schema = None

    if ooprops:
      schema = {'type':'object','required': list(
          self.properties.keys()), 'properties': ooprops}
      if self.description:
        schema['description'] = self.description
    elif ootype:
      schema = ootype

    return {
        self.name: schema
    }

  def handle_type(self, name, t, ooprops):
    if t in PRIMITIVE_TYPES:
      ooprops[name] = {'type': t}
    else:
      types = t.split()
      # Handle array of primitive types for now
      if types[0] == 'array' and types[1] in PRIMITIVE_TYPES:
        ooprops[name] = {'type': 'array', 'items': {'type': types[1]}}
      # Handle enum types
      elif types[0] == 'enum':
        ooprops[name] = {'type': 'string',
                         'enum': types[1][1:-1].split(',')}
      else:
        raise UnsupportedOpenAPIType(
            'Unsupported complex type used in schema: '+t)
