import yaml
import os
from openapi_spec_gen.openapi_objects import OpenAPIMethod, OpenAPIComponentSchema
# Detect comments in a header file.

OPENAPI_METHOD_TAG = '@openapi-method'
OPENAPI_SCHEMA_TAG = '@openapi-schema'
OPENAPI_INFO_FILE = 'openapi-info.yaml'

# TODO Capture error in comments and pinpoint to exact line where yaml parsing failed.


def find_comments(filename, process_fn=None):
  comments = []
  f = open(filename, 'r')
  current_comment = []
  in_comment = False
  for line in f:
    line = line.strip()
    if line.startswith('/**'):
      # Start of comment
      current_comment = []
      in_comment = True
    elif line.startswith('*/'):
      # End of comment
      in_comment = False
      if process_fn:
        openapi_obj = process_fn(current_comment)
        if openapi_obj:
          comments.append(openapi_obj)
      else:
        comments.append(current_comment)
    # Append all non-empty lines in the comment
    elif line and in_comment:
      current_comment.append(line)

  f.close()
  return comments


def parse_info(filename):
  return yaml.load(filename)


def comment_parser_cb(comment):
  if len(comment) == 0:
    return None
  # Only process openapi tagged comments
  clean_comments = '\n'.join([line.replace('*', '') for line in comment[1:]])
  oapi_obj = None
  if OPENAPI_METHOD_TAG in comment[0]:
    oapi_obj = OpenAPIMethod(yaml.safe_load(clean_comments))
  elif OPENAPI_SCHEMA_TAG in comment[0]:
    oapi_obj = OpenAPIComponentSchema(yaml.safe_load(clean_comments))
  return oapi_obj

# The parser itself.
# - Tries to find and parse openapi-info.yaml in the folder. If not it exists with error
# - Collects all comments and parse them as openapi methods (operations) and schema definitions.
# - Merge all definitions witn openapi info into a main object representing the API definition
# - Generate a yaml string from the document
# - Validate as an Open API 3.0 document using openapi-spec-validator


def parse(folder):
  oo_doc = {}
  try:
    with open(folder+'/'+OPENAPI_INFO_FILE, 'r') as stream:

      oo_doc = yaml.safe_load(stream)
  except yaml.YAMLError as e:
    print("ERROR: There was a problem parsing openapi-info.yaml as a YAML Document")
    raise e 
  except FileNotFoundError as e:
    print("ERROR: Missing openapi-info.yaml")
    raise e
  methods = {}
  schemas = {}
  for root, _, files in os.walk(folder):
    # We're only interested in header files.
    for file in [f for f in files if f.endswith(".h")]:
      comments = find_comments(os.path.join(root, file), comment_parser_cb)
      for comment in comments:
        if type(comment) is OpenAPIMethod:
          oom = comment.to_openapi()
          if methods.get(comment.path):
            methods[comment.path][comment.method] = oom[comment.path][comment.method]
          else:
            methods[comment.path] = oom[comment.path]
        elif type(comment) is OpenAPIComponentSchema:
          oom = comment.to_openapi()
          schemas[comment.name] = oom[comment.name]
  # Merge
  if 'content' in oo_doc:
    del oo_doc['content']
  oo_doc['paths'] = methods

  # This is to accommodate security definitions 
  if not oo_doc.get('components'):
    oo_doc['components'] = {}
  oo_doc['components']['schemas'] = schemas

  return oo_doc
