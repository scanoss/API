from openapi_spec_gen import openapi_objects as oo
from grappa import should
import yaml


def test_to_openapi_OpenAPIParam():
  param = oo.OpenAPIParam({'name': 'code', 'place': 'query',
                           'type': 'integer', 'description': 'The code parameter'})

  expected = {
      'name': 'code',
      'in': 'query',
      'description': 'The code parameter',
      'required': True,
      'schema': {
          'type': 'integer'
      }
  }

  param.to_openapi() | should.be.equal.to(expected)


def test_to_openapi_prop_OpenAPIParam():
  param = oo.OpenAPIParam({'name': 'code', 'place': 'query',
                           'type': 'integer', 'description': 'The code parameter'})

  expected = {
      'type': 'integer',
      'description': 'The code parameter',
  }

  param.to_openapi_prop() | should.be.equal.to(expected)


def test_to_openapi_OpenAPIResponse():
  # Complex type
  resp = oo.OpenAPIResponse(
      {'status': '201', 'description': 'Created', 'schema': 'Success'})

  expected = {
      '201': {
          'description': 'Created',
          'content': {
              'application/json': {
                  'schema': {
                      '$ref': '#/components/schemas/Success'
                  }
              }
          }

      }
  }
  resp.to_openapi() | should.be.equal.to(expected)

  # Simple Type
  resp = oo.OpenAPIResponse(
      {'status': '200', 'description': 'OK', 'schema': 'string'})

  expected = {
      '200': {
          'description': 'OK',
          'content': {
              'application/json': {
                  'schema': {
                      'type': 'string'
                  }
              }
          }

      }
  }

  resp.to_openapi() | should.be.equal.to(expected)

  # Empty response

  resp = oo.OpenAPIResponse({'status': '200', 'description': 'OK'})

  expected = {
      '200': {
          'description': 'OK'
      }
  }
  resp.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIMethod():
  yamlobj = yaml.safe_load("""
  operationId: listCodes
  request: GET /codes
  description: List all codes
  tags: codes
  params:
  - name: limit
    place: query
    type: integer
    required: false
    description: "How many items to return at one time (max 100)"
  responses:
  - status: 200
    description: "An paged array of pets"
    schema: Code
  - status: 500
    description: "unexpected error"
    schema: Error
  """)

  method = oo.OpenAPIMethod(yamlobj)

  expected = {
      '/codes': {
          'get': {
              'summary': 'List all codes',
              'operationId': 'listCodes',
              'tags': ['codes'],
              'parameters': [
                  {
                      'name': 'limit',
                      'in': 'query',
                      'description': 'How many items to return at one time (max 100)',
                      'required': False,
                      'schema': {
                          'type': 'integer'
                      }

                  }
              ],
              'responses':
                  {
                      '200': {
                          'description': 'An paged array of pets',
                          'content': {
                              'application/json': {
                                  'schema': {
                                      '$ref': '#/components/schemas/Code'
                                  }}
                          }
                      },


                      '500': {
                          'description': 'unexpected error',
                          'content': {
                              'application/json': {
                                  'schema': {
                                      '$ref': '#/components/schemas/Error'}
                              }
                          }
                      }
              }

          }
      }
  }

  method.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIMethod_without_params():
  yamlobj = yaml.safe_load("""
  operationId: listCodes
  request: GET /codes
  description: List all codes
  tags: codes
  responses:
  - status: 200
    description: "An paged array of pets"
    schema: Code
  """)

  method = oo.OpenAPIMethod(yamlobj)

  expected = {
      '/codes': {
          'get': {
              'summary': 'List all codes',
              'operationId': 'listCodes',
              'tags': ['codes'],
              'responses':
                  {
                      '200': {
                          'description': 'An paged array of pets',
                          'content': {
                              'application/json': {
                                  'schema': {
                                      '$ref': '#/components/schemas/Code'
                                  }}
                          }
                      }
              }

          }
      }
  }

  method.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIMethod_with_enum():
  yamlobj = yaml.safe_load("""
  operationId: listCodes
  request: GET /codes
  description: List all codes
  tags: codes
  params:
  - name: limit
    place: query
    type: enum [one,two,three]
    required: true
    description: "How many items to return at one time (max 100)"
  responses:
  - status: 200
    description: "An paged array of pets"
    schema: Code
  """)

  method = oo.OpenAPIMethod(yamlobj)

  expected = {
      '/codes': {
          'get': {
              'summary': 'List all codes',
              'operationId': 'listCodes',
              'tags': ['codes'],
              'parameters': [
                  {
                      'name': 'limit',
                      'in': 'query',
                      'description': 'How many items to return at one time (max 100)',
                      'required': True,
                      'schema': {
                          'type': 'string',
                          'enum': ['one', 'two', 'three']
                      }

                  }
              ],
              'responses':
                  {
                      '200': {
                          'description': 'An paged array of pets',
                          'content': {
                              'application/json': {
                                  'schema': {
                                      '$ref': '#/components/schemas/Code'
                                  }}
                          }
                      }
              }

          }
      }
  }

  method.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIComponentSchema():
  yamlobj = yaml.safe_load("""
    name: Error
    properties:
        code: integer
        message: string
    """)

  print(yamlobj)

  schema = oo.OpenAPIComponentSchema(yamlobj)

  expected = {
      'Error': {
          'required': ['code', 'message'],
          'properties': {
              'code': {
                  'type': 'integer'
              },
              'message': {
                  'type': 'string'
              }
          }
      }

  }

  schema.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIComponentSchema_with_array():
  yamlobj = yaml.safe_load("""
    name: Error
    properties:
        code: integer
        message: array string
    """)

  print(yamlobj)

  schema = oo.OpenAPIComponentSchema(yamlobj)

  expected = {
      'Error': {
          'required': ['code', 'message'],
          'properties': {
              'code': {
                  'type': 'integer'
              },
              'message': {
                  'type': 'array',
                  'items': {
                      'type': 'string'
                  }
              }
          }
      }

  }

  schema.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIComponentSchema_with_enum():
  yamlobj = yaml.safe_load("""
    name: Error
    properties:
        code: integer
        status: enum [one,two,three]
    """)

  print(yamlobj)

  schema = oo.OpenAPIComponentSchema(yamlobj)

  expected = {
      'Error': {
          'required': ['code', 'status'],
          'properties': {
              'code': {
                  'type': 'integer'
              },
              'status': {
                  'type': 'string',
                  'enum': ['one', 'two', 'three']
              }
          }
      }

  }

  schema.to_openapi() | should.be.equal.to(expected)


def test_parse_User_schema():
  yamlobj = yaml.safe_load("""
    name: User
    properties:
      name: string
      roles: array string
    """)

  print(yamlobj)

  schema = oo.OpenAPIComponentSchema(yamlobj)

  expected = {
      'User': {
          'required': ['name', 'roles'],
          'properties': {
              'name': {
                  'type': 'string'
              },
              'roles': {
                  'type': 'array',
                  'items': {
                      'type': 'string'
                  }
              }
          }
      }

  }

  schema.to_openapi() | should.be.equal.to(expected)


def test_parse_OpenAPIComponentSchema_with_description():
  yamlobj = yaml.safe_load("""
    name: Error
    properties:
        code: integer
        message: 
            type: string
            description: The error code
    """)

  print(yamlobj)

  schema = oo.OpenAPIComponentSchema(yamlobj)

  expected = {
      'Error': {
          'required': ['code', 'message'],
          'properties': {
              'code': {
                  'type': 'integer'
              },
              'message': {
                  'type': 'string',
                  'description': 'The error code'
              }
          }
      }

  }
  schema.to_openapi() | should.be.equal.to(expected)
