from openapi_spec_gen import parser

def test_find_comments():
  c = parser.find_comments('examples/project1/code.h')
  print(c)
  assert len(c) == 3
  
  
