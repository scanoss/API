from openapi_spec_gen import command_line
import sys

def test_main_project1():
  original = sys.stdout
  sys.stdout = open('command_line_test.yaml', 'w')
  sys.argv = ['openapi-spec-gen','examples/project1']
  command_line.main()
  
  sys.stdout = original
  